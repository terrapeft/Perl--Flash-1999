Alternate WinAmp Skin by
Killer Whale John (killerjohn@mail.ru)
Web Page : http://julie-bowen.narod.ru, http://dimonius.da.ru

This is an alternate frontend for Nullsoft's WinAmp.
(visit http://www.nullsoft.com and http://www.winamp.com for more info).

Created by WinAmp Skins Creator. TiGER grp. Visit http://dimonius.da.ru for more infos

Skin Master       : Killer Whale John
Master's E-mail   : killerjohn@mail.ru
Master's Web Page : http://julie-bowen.narod.ru

Style Infos:
This style created by 
SimBa aka Dimoniusis. 

It's a Default Style for 
WinAmp Skin Creator.

Visit http://dimonius.da.ru 
for more info.
------------

Unzip all files to the \winamp\skins\ directory. Then choose Options,
Select skin from the pulldown menu.
This skin uses 24-bit graphics

By TiGER grp. 2000.
